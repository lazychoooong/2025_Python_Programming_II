class Student:
    def __init__(self, stu_id, name):
        self.stu_id=stu_id
        self.name=name
    
    def __eq__

root.title("중간고사 5번")