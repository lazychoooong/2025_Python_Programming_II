class BankAccount:
    def __init__(self, owner, balance):
        self.owner=owner
        self.balance=balance
        print(f"{self_owner}계좌가 생성되었습니다.")

    def deposit(self, amount):
        if amount > 0:
            print(f"{self_owner} 통장에서 {amount}원이 입금되었습니다.")
        else:
            print("0보다 큰 금액만 입금 가능합니다")

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
            print(f"{self_owner} 통장에서 {amount}원이 출금되었습니다.")
        else:
            print("잔액이 부족합니다")

    def get_balance(self, amount):
        return amount
        print(f"{self_owner} 통장의 현재 잔액 : {amount}")

    def set_balance(self, amount):
        if amount > 0:
            print(f"{self_owner} 통장의 수정된 잔액 : {amount}")
    


a = BankAccount("A")
b = BankAccount("B")

a.deposit(100)
b.deposit(100)
a.withdraw(30)
b.withdraw(50)
