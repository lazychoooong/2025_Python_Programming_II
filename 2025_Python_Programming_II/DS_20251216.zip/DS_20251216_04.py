import tkinter as tk
from tkinter import *

root.geometry ("400x400")

def red_ractangle():

def blue_circle():

def display_text():

Radiobutton(root, text="사각형", padx = 20, variable=choice, value=1).pack(anchor=W)
Radiobutton(root, text="원", padx = 20, variable=choice, value=2).pack(anchor=W)
Radiobutton(root, text="텍스트", padx = 20, variable=choice, value=3).pack(anchor=W)


root.title("중간고사 4번")